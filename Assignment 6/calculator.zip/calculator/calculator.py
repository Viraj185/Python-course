import tkinter as tk
from tkinter import ttk
from tkinter import Entry

windows = tk.Tk()
windows.geometry("300x300")
windows.title("Calculator")

user_input = Entry(windows,width=50)
user_input.grid(row=0, column=0, columnspan=4, padx=10, pady=10, sticky="nsew")

def click(num):
    result = user_input.get()
    user_input.insert(tk.END,str(num))

button = ttk.Button(windows,text="1",command=lambda: click(1))
button.grid(row=1, column=0)

button = ttk.Button(windows,text="2",command=lambda: click(2))
button.grid(row=1, column=1)

button = ttk.Button(windows,text="3",command=lambda: click(3))
button.grid(row=1, column=2)

button = ttk.Button(windows,text="4",command=lambda: click(4))
button.grid(row=2, column=0)

button = ttk.Button(windows,text="5",command=lambda: click(5))
button.grid(row=2, column=1)

button = ttk.Button(windows,text="6",command=lambda: click(6))
button.grid(row=2, column=2)

button = ttk.Button(windows,text="7",command=lambda: click(7))
button.grid(row=3, column=0)

button = ttk.Button(windows,text="8",command=lambda: click(8))
button.grid(row=3, column=1)

button = ttk.Button(windows,text="9",command=lambda: click(9))
button.grid(row=3, column=2)

button = ttk.Button(windows,text="0",command=lambda: click(0))
button.grid(row=4, column=0)

def add():
    n1 = user_input.get()
    global math
    math = "add"
    global i
    i = int(n1)
    user_input.delete(0,tk.END)

button = ttk.Button(windows,text="+",command=add)
button.grid(row=4, column=1)

def sub():
    n1 = user_input.get()
    global math
    math = "sub"
    global i
    i = int(n1)
    user_input.delete(0,tk.END)

button = ttk.Button(windows,text="-",command=sub)
button.grid(row=4, column=2)

def mul():
    n1 = user_input.get()
    global math
    math = "mul"
    global i
    i = int(n1)
    user_input.delete(0,tk.END)

button = ttk.Button(windows,text="*",command=mul)
button.grid(row=5, column=0)

def div():
    n1 = user_input.get()
    global math
    math = "div"
    global i
    i = int(n1)
    user_input.delete(0,tk.END)

button = ttk.Button(windows,text="/",command=div)
button.grid(row=5, column=1)

def result():
    n2 = user_input.get()
    user_input.delete(0,tk.END)
    if math == "add":
        user_input.insert(0,i+int(n2))
    elif math == "sub":
        user_input.insert(0,i-int(n2))
    elif math == "mul":
        user_input.insert(0,i*int(n2))
    elif math == "div":
        user_input.insert(0,i/int(n2))

button = ttk.Button(windows,text="=",command=result)
button.grid(row=5, column=2)

def clear():
 
    user_input.delete(0,tk.END)
button =ttk.Button(windows,text="C",command=clear)
button.grid(row=6, column=0)


windows.mainloop()